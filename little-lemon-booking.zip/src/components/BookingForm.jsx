import React, { useState } from "react";

export default function BookingForm({ availableTimes, dispatch, submitForm }) {
  const [formData, setFormData] = useState({
    date: "",
    time: "",
    guests: 1,
    occasion: "Birthday"
  });

  const [errors, setErrors] = useState({});

  const validate = () => {
    let newErrors = {};
    if (!formData.date) newErrors.date = "Date is required";
    if (!formData.time) newErrors.time = "Time is required";
    if (formData.guests < 1 || formData.guests > 10)
      newErrors.guests = "Guests must be 1-10";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });

    if (e.target.name === "date") {
      dispatch({ type: "UPDATE_TIMES", date: e.target.value });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      submitForm(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} aria-label="Booking Form">
      <label htmlFor="date">Choose date</label>
      <input type="date" id="date" name="date" required onChange={handleChange}/>
      {errors.date && <p role="alert">{errors.date}</p>}

      <label htmlFor="time">Choose time</label>
      <select id="time" name="time" required onChange={handleChange}>
        <option value="">Select time</option>
        {availableTimes.map((time) => (
          <option key={time}>{time}</option>
        ))}
      </select>
      {errors.time && <p role="alert">{errors.time}</p>}

      <label htmlFor="guests">Guests</label>
      <input type="number" id="guests" name="guests" min="1" max="10" onChange={handleChange}/>
      {errors.guests && <p role="alert">{errors.guests}</p>}

      <label htmlFor="occasion">Occasion</label>
      <select id="occasion" name="occasion" onChange={handleChange}>
        <option>Birthday</option>
        <option>Anniversary</option>
      </select>

      <button type="submit">Reserve Table</button>
    </form>
  );
}
