export default function ConfirmedBooking() {
  return (
    <main>
      <h1>Booking Confirmed!</h1>
      <p>Your reservation has been successfully submitted.</p>
    </main>
  );
}
