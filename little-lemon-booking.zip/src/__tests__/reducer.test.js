import { initializeTimes } from "../reducer";

test("initializeTimes returns correct times", () => {
  expect(initializeTimes()).toContain("17:00");
});
