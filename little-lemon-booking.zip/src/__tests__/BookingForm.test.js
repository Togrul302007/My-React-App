import { render, screen } from "@testing-library/react";
import BookingForm from "../components/BookingForm";

test("renders date label", () => {
  render(<BookingForm availableTimes={["17:00"]} dispatch={() => {}} submitForm={() => {}} />);
  expect(screen.getByLabelText(/choose date/i)).toBeInTheDocument();
});
