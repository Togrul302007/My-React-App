# Little Lemon Booking App

## Features
- useReducer state management
- Form validation
- Accessibility support
- Mock API
- Unit tests
- Responsive UI

## Setup

npm install
npm start
npm test
